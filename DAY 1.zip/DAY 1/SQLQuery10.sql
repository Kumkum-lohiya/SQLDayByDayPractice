/* Retrive all customers and sort the results by the highest score first */

SELECT * 
FROM customers
ORDER BY score DESC